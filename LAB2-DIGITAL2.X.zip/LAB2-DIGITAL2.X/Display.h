/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef DISPLAY_H
#define	DISPLAY_H

#include <xc.h> // include processor files - each processor file is guarded. 
#include <stdint.h>

//******************************************************************************
//initOsc
// N�mero para mostrar en el display en hexadecimal
// En el par�metro NUM se coloca el valor en decimal que se quiere que aparezca 
// en el display y se carga los leds del display para que aparezca
//******************************************************************************
uint8_t display(uint8_t ADC_VALOR);

#endif	/* DISPLAY_H */

