/*
 * Pseudocodigo -- Laboratorio # 3
 * Author: Natalia de Le�n Berci�n
 * carn�: 18193
 * Digital 2
 *
 * Created on 7 de febrero de 2021
 */

//****************************************************************************//
//IMPORTAR LIBRERIAS                                                          //
//****************************************************************************//
#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include <pic16f887.h>
#include "Oscilador.h"
#include "LCD.h"
#include "Config_ADC.h"
#include "USART.h"


//****************************************************************************//
//CONFIGURACION BITS                                                          //
//****************************************************************************//
// CONFIG1
#pragma config FOSC = XT // Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

//****************************************************************************//
//DEFINE                                                                      //
//****************************************************************************//
#define _XTAL_FREQ 8000000

#define RS PORTEbits.RE0
#define RW PORTEbits.RE1
#define EN PORTEbits.RE2
#define D0 PORTDbits.RD0
#define D1 PORTDbits.RD1
#define D2 PORTDbits.RD2
#define D3 PORTDbits.RD3
#define D4 PORTDbits.RD4
#define D5 PORTDbits.RD5
#define D6 PORTDbits.RD6
#define D7 PORTDbits.RD7

//****************************************************************************//
//VARIABLES                                                                   //
//****************************************************************************//

float S1_val = 0.0;
float S2_val = 0.0;
//uint8_t S1_val;
//uint8_t S2_val;
//uint8_t S1_val_1;
//uint8_t S2_val_2;
//char* data1[8];
//char* data2[8];
//char* S3_cont[3];
char data_total[20];
uint8_t cont;
char data_recive;
//****************************************************************************//
//PROTOTIPOS DE FUNCIONES                                                     //
//****************************************************************************//
void setup(void); 
void Config_INTERRUPT(void);
void ADC_INTERRUPT(void);
//void Trasmission(void);// funcion para constantemente mandar los valores ADC
//void Receive(void); //funcion para constantemente recibir datos de la compu
//void titulos_LCD(void);
void ADC_channel1(void);
void ADC_channel2(void);
void ADC_to_string(void);
void Show_val_LCD(void);
//****************************************************************************//
//INTERRUPCIONES                                                              //
//****************************************************************************//
void __interrupt() ISR(void){
    if (PIR1bits.RCIF == 1){
        data_recive = RCREG;
        //cont++;
        if (data_recive == '+'){
            cont++;
            PORTB = cont;
        }
        if (data_recive == '-'){
            cont--;
        }
        else {
            cont++;
            PORTB = cont;
        }
        data_recive = 0;
        }
    //return;
} 

//****************************************************************************//
//PROGRAMACION PRINCIPAL                                                      //
//****************************************************************************//
void main(void) {
    setup(); //Configuracion de puertos de entrada y salida
    USART_Init_BaudRate();
    USART_Init();
    USART_INTERRUPT();
    Lcd_Init();
    Lcd_Clear();
    cont = 0;
    
    //************************************************************************//
    //LOOP PRINCIPAL                                                          //
    //************************************************************************//
    while (1) {
        //PORTB = data_recive;
        ADC_channel1();
        __delay_ms(1);
        ADC_channel2();
        
        Write_USART_String("S1     S2   Cont ");
        ADC_to_string();
        Write_USART_String(data_total);//enviar el string con los valores a la pc
        Write_USART(13);//13 y 10 la secuencia es para dar un salto de linea 
        Write_USART(10);
        Show_val_LCD();
        __delay_ms(500);

        //Trasmission();
        
//        if (PIR1bits.RCIF == 1){
//            data_recive = RCREG;
//            //cont++;
//            if (data_recive == '+'){
//                cont++;
//                PORTB = cont;
//            }
//            if (data_recive == '-'){
//                cont--;
//            }
//        data_recive = 0;
//        }
        
        
         
}
}
//****************************************************************************//
//FUNCIONES                                                                   //
//****************************************************************************//
void ADC_channel1(void){
    ADC_Config (0);
    __delay_ms(1); //Inicio de conversion ADC
    ADCON0bits.GO = 1;
    while (ADCON0bits.GO != 0) { //Mientras no se haya termindo una convers.
        //S1_val_1 = ADRESH;
        S1_val = ((ADRESH * 5.0) / 255);
    }
}

void ADC_channel2(void){
    ADC_Config (1);
    __delay_ms(1); //Inicio de conversion ADC
    ADCON0bits.GO = 1;
    while (ADCON0bits.GO != 0) { //Mientras no se haya termindo una convers.
        //S2_val_2 = ADRESH;
        S2_val = ((ADRESH * 5.0) / 255);
    }
}

void ADC_to_string(void){
    //sprintf(data_total, "%1.2fV %1.2fV", S1_val, S2_val);
    sprintf(data_total, "%2.1fV  %2.1fV    %d", S2_val, S1_val, cont);
//    sprintf(data2, "%.3iV", S1_val_1<<1); //poner las conversiones en numeros, 
//    sprintf(data1, "%.3iV", S2_val_2<<1); // segun el voltaje
//    sprintf(S3_cont, "%.3i", cont);
}

void Show_val_LCD(void){
    //Valores de S1 y S2
    Lcd_Clear();
    Lcd_Set_Cursor(1,2); //nombres S1, S2 y S3
    Lcd_Write_String("S1:   S2:   S3:");
    Lcd_Set_Cursor(2,1);
    Lcd_Write_String(data_total);
}

//********************* CONFIGURACION PRINCIPAL ******************************//

void setup(void) { //Configuraci�n de puertos de entrada y salida
    initOsc(0b00000110); //8MHz
    ANSEL = 0b00000011; //RA0 y RA1 como analogico
    ANSELH = 0; 
    TRISA = 0b00000011; //potenciometros, como entrada
    TRISB = 0;
    TRISCbits.TRISC6 = 0;
    TRISCbits.TRISC7 = 1;
    TRISD = 0; 
    TRISE = 0;
    PORTA = 0; 
    PORTB = 0;
    PORTC = 0;
    PORTD = 0;
    PORTE = 0;
}
//********************* CONFIGURACION COM SERIAL *****************************//


